﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment1.Models
{
    public class Student
    {
        public long SSN { get; set; }
        public String Name { get; set; }
    }
}
