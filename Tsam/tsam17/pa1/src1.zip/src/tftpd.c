#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <limits.h>
#include <arpa/inet.h>
#include <unistd.h>

struct RRQ
{
  unsigned short opcode;
  char filename[256];
  char mode[9];
};

struct ACK
{
  unsigned short opcode;
  unsigned short block;
};

struct DATA
{
  unsigned short opcode;
  unsigned short block;
  char data[512];
};

struct ERR
{
  unsigned short opcode;
  unsigned short errorcode;
  char errmsg[512];
};



void Error(char *message)
{
  fprintf(stderr, "Error %s\n", message);
  exit(0);
};

int main(int argc, char**argv)
{
  // To open a file
  const char* dir = "./data/";
  char* path;
  size_t path_size;
  //
  int sockfd;
  struct sockaddr_in server, client;
  struct timeval timeout;
  timeout.tv_sec = 30;
  timeout.tv_usec = 0;
  struct RRQ readrequest;
  struct ERR errormessage;
  struct DATA datablock;
  struct ACK ackmessage;
  char *p;
  char* client_ip;
  socklen_t client_len;
  FILE *file;
  int sendsize;
  int counter;

  // Convert string to unsigned short for port and check if there is an error.

  unsigned short port = ((unsigned short)strtol(argv[1], &p, 10));
  if (errno != 0 || *p != '\0'  || port > USHRT_MAX)
  {
    Error("INVALID PORT");
  }

  // AF_INET = ipv4 up adress.
  // SOCK_DGRAM because we are using UDP.
  // IF SOCKFD returns -1 then error and have to shut down the serv.
while(1)
{
  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  //setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
  if (sockfd < 0){
    Error("failed to create socket");
  }
  //Initialize server.
  //init(port, &server);
  memset(&server, 0, sizeof(server));
  server.sin_family = AF_INET;
  server.sin_port = htons(port);
  server.sin_addr.s_addr = htonl(INADDR_ANY);

  int error = bind(sockfd, (struct sockaddr *) &server, (socklen_t) sizeof(server));;
  if (error < 0)
  {
    Error("did not success binding socket to port.");
  }

  client_len = (socklen_t) sizeof(client);
  printf("\nlistening to port %hu \n\n", port);

  ssize_t n = recvfrom(sockfd, (char *)&readrequest, sizeof(readrequest), 0, (struct sockaddr *)&client, &client_len);

  if (n < 0)
  {
    Error("No package received");
  }

  client_ip = inet_ntoa(client.sin_addr);

  fprintf(stdout, "Package recieved from: %s on port %u \n", client_ip, client.sin_port);
  fprintf(stdout, "User requested the file: %s\n", readrequest.filename);

  //size of the path that fopen has to open.
  path_size = strlen(dir) + strlen(readrequest.filename) + 1;
  //allocating the size in memory
  path = malloc(path_size);
  //creating the file path by joining dir and filename
  snprintf(path, path_size, "%s%s", dir, readrequest.filename);

  file = fopen(path, "rb");
  free(path);
  if (file == NULL)
  {
    char *msg;
    msg = (char*) malloc(15);
    strcpy(msg, "File not found");

    strcpy(errormessage.errmsg, msg);
    errormessage.opcode = htons(5);
    errormessage.errorcode = htons(1);

    sendto(sockfd, &errormessage, 512 + 4, 0, (struct sockaddr *)&client, client_len);
    fprintf(stdout, "%s\n",msg);
    close(sockfd);
    free(msg);
    continue;
  }

  fprintf(stdout, "File found\n");
    // TRANSFER DATA
  counter = 1;

  while(1)
  {
    sendsize = fread(datablock.data, 1, 512, file);
    datablock.opcode = htons(3);
    datablock.block = htons(counter);

    sendto(sockfd, &datablock, sendsize + 4, 0, (struct sockaddr *)&client, client_len);
    ssize_t y = recvfrom(sockfd, (char *)&ackmessage, sizeof(ackmessage), 0, (struct sockaddr *)&client, &client_len);
   
    if (y < 0)
    {
        Error("No package received");
    }
  
    if (htons(ackmessage.opcode) != 4)
    {
        Error("Failed sending file");
    }

    counter = counter + 1;
    memset(&datablock.data[0], 0, sizeof(datablock.data));

    if (sendsize != 512)
    {
        printf("Completed");
        fflush(stdout);
        close(sockfd);
        fclose(file);
        break;
    }

  }
  close(sockfd);
}
  return 0;
}

























